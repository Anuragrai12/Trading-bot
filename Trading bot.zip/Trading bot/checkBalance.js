require('dotenv').config();
const ccxt = require('ccxt');

// Initialize Binance Testnet Client
const exchange = new ccxt.binance({
    apiKey: process.env.BINANCE_API_KEY,
    secret: process.env.BINANCE_API_SECRET,
    enableRateLimit: true,
});

// VERY IMPORTANT: Set sandbox mode to TRUE to use the Testnet!
exchange.setSandboxMode(true); 

async function checkMyBalance() {
    console.log("🔄 Fetching your Binance Testnet balance...\n");
    try {
        const balance = await exchange.fetchBalance();
        
        console.log("===================================");
        console.log("💰 YOUR CURRENT WALLET BALANCE 💰");
        console.log("===================================");
        
        // Binance Testnet gives a lot of coins, we'll only print the ones you have a balance for
        let hasCoins = false;
        for (const coin in balance.total) {
            if (balance.total[coin] > 0) {
                console.log(`- ${coin}: ${balance.total[coin]}`);
                hasCoins = true;
            }
        }

        if (!hasCoins) {
            console.log("Your wallet is empty.");
        }
        
        console.log("===================================\n");

    } catch (error) {
        console.error("❌ Error fetching balance. Make sure your API keys are correct in the .env file.");
        console.error("Details:", error.message);
    }
}

checkMyBalance();
