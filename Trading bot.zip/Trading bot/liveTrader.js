require('dotenv').config();
const ccxt = require('ccxt');
const { getHistoricalData } = require('./dataFetcher');
const { analyzeDataAndGetSignal } = require('./strategy');

// Initialize Binance Testnet Client
const exchange = new ccxt.binance({
    apiKey: process.env.BINANCE_API_KEY,
    secret: process.env.BINANCE_API_SECRET,
    enableRateLimit: true,
});

// VERY IMPORTANT: Set sandbox mode to TRUE to use the Testnet!
exchange.setSandboxMode(true); 

async function checkBalance() {
    try {
        const balance = await exchange.fetchBalance();
        console.log(`🏦 Current Balance: ${balance.USDT?.free || 0} USDT | ${balance.BTC?.free || 0} BTC`);
        return balance;
    } catch (error) {
        console.error("❌ Error fetching balance. Check your API keys in .env file.");
        return null;
    }
}

async function placeOrder(symbol, side, amount) {
    try {
        console.log(`⏳ Placing ${side} order for ${amount} ${symbol}...`);
        // Using a Market order for immediate execution
        const order = await exchange.createMarketOrder(symbol, side, amount);
        console.log(`✅ Order Successful! Order ID: ${order.id} | Price: $${order.price || 'Market'}`);
        return order;
    } catch (error) {
        console.error("❌ Order Failed:", error.message);
        return null;
    }
}

async function main() {
    console.log("🤖 Starting LIVE Trading Bot (Binance Testnet)...");
    
    // 1. Verify Connection and Balance
    const balance = await checkBalance();
    if (!balance) {
        console.log("Exiting... Please fix API keys.");
        return;
    }

    const SYMBOL = 'BTC/USDT'; // CCXT uses slash notation
    const FETCH_SYMBOL = 'BTCUSDT'; // Binance raw API format for our fetcher
    const TRADE_AMOUNT_USDT = 100; // We will trade $100 worth of BTC at a time
    let inPosition = false; // Simple flag to track if we currently hold BTC

    console.log("[*] Entering live trading loop. Press Ctrl+C to stop.");
    
    // Run loop every 10 seconds
    setInterval(async () => {
        try {
            // 1. Fetch market data
            const data = await getHistoricalData(FETCH_SYMBOL, '1m', 50);
            if (!data) return;
            const currentPrice = data[data.length - 1].close;

            // 2. Get Strategy Signal
            const signal = analyzeDataAndGetSignal(data);
            console.log(`💡 Signal: ${signal} | Current Price: $${currentPrice.toFixed(2)}`);

            // 3. Execute Real Orders
            if (signal === "BUY" && !inPosition) {
                // Calculate how much BTC we can buy with 100 USDT
                const btcAmountToBuy = TRADE_AMOUNT_USDT / currentPrice;
                const roundedAmount = exchange.amountToPrecision(SYMBOL, btcAmountToBuy);
                
                const order = await placeOrder(SYMBOL, 'buy', roundedAmount);
                if (order) inPosition = true;
            } 
            else if (signal === "SELL" && inPosition) {
                // Fetch balance to know exactly how much BTC we have to sell
                const currentBalance = await exchange.fetchBalance();
                const btcToSell = currentBalance.BTC?.free;
                
                if (btcToSell > 0) {
                    const roundedAmount = exchange.amountToPrecision(SYMBOL, btcToSell);
                    const order = await placeOrder(SYMBOL, 'sell', roundedAmount);
                    if (order) inPosition = false;
                }
            }
        } catch (err) {
            console.error("Error in trading loop:", err.message);
        }
    }, 10000); // Check every 10 seconds
}

main().catch(console.error);
