// ===== Dashboard App Logic =====

let priceChart = null;

// Format numbers nicely
function formatPrice(price) {
    return '$' + parseFloat(price).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatTime(isoString) {
    const d = new Date(isoString);
    return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function formatUptime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h}h ${m}m ${s}s`;
}

// ===== Fetch & Update Market Data =====
async function updateMarketData() {
    try {
        const res = await fetch('/api/market');
        const data = await res.json();
        if (!data.success) return;

        // Update BTC Price
        const priceEl = document.getElementById('btcPrice');
        const oldPrice = priceEl.dataset.price ? parseFloat(priceEl.dataset.price) : 0;
        priceEl.textContent = formatPrice(data.currentPrice);
        priceEl.dataset.price = data.currentPrice;
        
        const changeEl = document.getElementById('btcChange');
        if (oldPrice > 0) {
            const diff = data.currentPrice - oldPrice;
            const pct = ((diff / oldPrice) * 100).toFixed(3);
            changeEl.textContent = diff >= 0 ? `▲ +${pct}%` : `▼ ${pct}%`;
            changeEl.style.color = diff >= 0 ? '#10b981' : '#ef4444';
        }

        // Update Signal
        const signalEl = document.getElementById('signalValue');
        signalEl.textContent = data.signal;
        signalEl.className = 'stat-value signal-text';
        if (data.signal === 'BUY') signalEl.classList.add('signal-buy');
        else if (data.signal === 'SELL') signalEl.classList.add('signal-sell');
        else signalEl.classList.add('signal-hold');

        const signalInfo = document.getElementById('signalInfo');
        signalInfo.textContent = `SMA(20): ${formatPrice(data.sma)}`;

        // Update RSI
        const rsi = parseFloat(data.rsi);
        document.getElementById('rsiValue').textContent = rsi.toFixed(1);
        const rsiBar = document.getElementById('rsiBar');
        rsiBar.style.width = `${rsi}%`;
        if (rsi < 30) rsiBar.style.background = 'linear-gradient(90deg, #10b981, #34d399)';
        else if (rsi > 70) rsiBar.style.background = 'linear-gradient(90deg, #ef4444, #f87171)';
        else rsiBar.style.background = 'linear-gradient(90deg, #6366f1, #22d3ee)';

        // Update Chart
        updateChart(data.chartData);

    } catch (err) {
        console.error('Market update error:', err);
    }
}

// ===== Update Price Chart =====
function updateChart(chartData) {
    const labels = chartData.map(c => formatTime(c.time));
    const prices = chartData.map(c => c.close);

    if (!priceChart) {
        const ctx = document.getElementById('priceChart').getContext('2d');
        
        const gradient = ctx.createLinearGradient(0, 0, 0, 300);
        gradient.addColorStop(0, 'rgba(99, 102, 241, 0.3)');
        gradient.addColorStop(1, 'rgba(99, 102, 241, 0.0)');

        priceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'BTC/USDT',
                    data: prices,
                    borderColor: '#6366f1',
                    backgroundColor: gradient,
                    borderWidth: 2.5,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0,
                    pointHoverRadius: 6,
                    pointHoverBackgroundColor: '#6366f1',
                    pointHoverBorderColor: '#fff',
                    pointHoverBorderWidth: 2,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { intersect: false, mode: 'index' },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(17, 24, 39, 0.95)',
                        borderColor: 'rgba(99, 102, 241, 0.3)',
                        borderWidth: 1,
                        titleColor: '#94a3b8',
                        bodyColor: '#f1f5f9',
                        bodyFont: { size: 14, weight: '600' },
                        padding: 12,
                        cornerRadius: 8,
                        displayColors: false,
                        callbacks: {
                            label: (ctx) => `$${ctx.parsed.y.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { color: 'rgba(255,255,255,0.03)', drawBorder: false },
                        ticks: { color: '#64748b', font: { size: 10 }, maxTicksLimit: 8 }
                    },
                    y: {
                        grid: { color: 'rgba(255,255,255,0.03)', drawBorder: false },
                        ticks: {
                            color: '#64748b',
                            font: { size: 11 },
                            callback: (val) => '$' + val.toLocaleString()
                        }
                    }
                }
            }
        });
    } else {
        priceChart.data.labels = labels;
        priceChart.data.datasets[0].data = prices;
        priceChart.update('none');
    }
}

// ===== Fetch & Update Wallet Balance =====
async function updateBalance() {
    try {
        const res = await fetch('/api/balance');
        const data = await res.json();
        if (!data.success) return;

        const walletList = document.getElementById('walletList');
        walletList.innerHTML = '';

        const coinIcons = {
            BTC: '₿', USDT: '₮', ETH: 'Ξ', BNB: 'B',
            SOL: 'S', DOGE: 'D', XRP: 'X'
        };

        for (const [coin, info] of Object.entries(data.balance)) {
            const iconClass = `coin-${coin.toLowerCase()}`;
            const item = document.createElement('div');
            item.className = 'wallet-item';
            item.innerHTML = `
                <div class="wallet-coin-info">
                    <div class="coin-icon ${iconClass}">${coinIcons[coin] || coin[0]}</div>
                    <span class="coin-name">${coin}</span>
                </div>
                <div class="wallet-amount">
                    <div class="amount">${parseFloat(info.total).toLocaleString('en-US', { maximumFractionDigits: 4 })}</div>
                    <div class="label">Available: ${parseFloat(info.free).toLocaleString('en-US', { maximumFractionDigits: 4 })}</div>
                </div>
            `;
            walletList.appendChild(item);
        }
    } catch (err) {
        console.error('Balance error:', err);
    }
}

// ===== Fetch & Update Trade History =====
async function updateTrades() {
    try {
        const res = await fetch('/api/trades');
        const data = await res.json();
        const tbody = document.getElementById('tradesBody');

        if (!data.success) {
            const row = document.createElement('tr');
            const cell = document.createElement('td');
            cell.colSpan = 5;
            cell.className = 'no-trades';
            cell.textContent = `Trade history unavailable: ${data.error || 'Could not reach Binance Testnet.'}`;
            row.appendChild(cell);
            tbody.replaceChildren(row);
            return;
        }
        
        if (data.trades.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="no-trades">No trades yet. Bot is watching the market... 👀</td></tr>';
            return;
        }

        tbody.innerHTML = data.trades.reverse().map(trade => `
            <tr>
                <td>${formatTime(trade.time)}</td>
                <td><span class="trade-type-${trade.type.toLowerCase()}">${trade.type}</span></td>
                <td>${formatPrice(trade.price)}</td>
                <td>${trade.amount}</td>
                <td>${formatPrice(trade.value)}</td>
            </tr>
        `).join('');

    } catch (err) {
        console.error('Trades error:', err);
    }
}

// ===== Fetch Bot Status =====
async function updateStatus() {
    try {
        const res = await fetch('/api/status');
        const data = await res.json();
        if (!data.success) return;

        document.getElementById('totalTrades').textContent = data.totalTrades;
        document.getElementById('uptime').textContent = `Uptime: ${formatUptime(data.uptime)}`;
    } catch (err) {
        console.error('Status error:', err);
    }
}

// ===== Initial Load & Auto-Refresh =====
async function init() {
    await Promise.all([
        updateMarketData(),
        updateBalance(),
        updateTrades(),
        updateStatus()
    ]);

    // Auto refresh
    setInterval(updateMarketData, 5000);   // Every 5 seconds
    setInterval(updateBalance, 30000);     // Every 30 seconds
    setInterval(updateTrades, 10000);      // Every 10 seconds
    setInterval(updateStatus, 10000);      // Every 10 seconds
}

// Start!
init();
