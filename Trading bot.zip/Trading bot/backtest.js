const { getHistoricalData } = require('./dataFetcher');
const { analyzeDataAndGetSignal } = require('./strategy');

async function runBacktest() {
    console.log("🛠️ Starting Backtest...");
    
    // Fetch a large amount of historical data (e.g., 1000 hours of 1h candles)
    // Binance max limit per request is 1000
    const data = await getHistoricalData('BTCUSDT', '1h', 1000);
    
    if (!data || data.length < 50) {
        console.log("Not enough data to backtest.");
        return;
    }

    console.log(`Fetched ${data.length} candles for backtesting. (${data[0].time.toLocaleString()} to ${data[data.length-1].time.toLocaleString()})`);

    let balance = 1000; // Start with $1000
    let position = 0; // BTC held
    let entryPrice = 0;
    
    // Risk Parameters
    const STOP_LOSS_PERCENT = 0.02;
    const TAKE_PROFIT_PERCENT = 0.05;

    let trades = 0;
    let winningTrades = 0;
    let losingTrades = 0;

    // Loop through historical data starting from the 21st candle (since we need 20 for SMA)
    for (let i = 20; i < data.length; i++) {
        // Slice the data up to the current candle to simulate past knowledge
        const historicalSlice = data.slice(0, i + 1);
        const currentCandle = historicalSlice[historicalSlice.length - 1];
        const currentPrice = currentCandle.close;

        // Check Risk Management first
        if (position > 0) {
            const lossPrice = entryPrice * (1 - STOP_LOSS_PERCENT);
            const profitPrice = entryPrice * (1 + TAKE_PROFIT_PERCENT);

            if (currentPrice <= lossPrice) {
                balance = position * currentPrice;
                position = 0;
                entryPrice = 0;
                trades++;
                losingTrades++;
                continue; // Move to next candle
            } else if (currentPrice >= profitPrice) {
                balance = position * currentPrice;
                position = 0;
                entryPrice = 0;
                trades++;
                winningTrades++;
                continue; // Move to next candle
            }
        }

        // Get signal using only the data available up to that point
        // Note: strategy.js has a console.log which will spam. 
        // For a clean backtest, we temporarily mock console.log to hide strategy logs.
        const originalLog = console.log;
        console.log = () => {}; 
        const signal = analyzeDataAndGetSignal(historicalSlice);
        console.log = originalLog; // Restore console.log

        if (signal === "BUY" && balance > 0) {
            position = balance / currentPrice;
            entryPrice = currentPrice;
            balance = 0;
        } 
        else if (signal === "SELL" && position > 0) {
            balance = position * currentPrice;
            if (currentPrice > entryPrice) {
                winningTrades++;
            } else {
                losingTrades++;
            }
            position = 0;
            entryPrice = 0;
            trades++;
        }
    }

    // Sell any remaining position at the end of the backtest
    if (position > 0) {
        const finalPrice = data[data.length - 1].close;
        balance = position * finalPrice;
        if (finalPrice > entryPrice) winningTrades++;
        else losingTrades++;
        trades++;
        position = 0;
    }

    console.log("\n=================================");
    console.log("📊 BACKTEST RESULTS (RSI + SMA Strategy)");
    console.log("=================================");
    console.log(`Initial Investment: $1000.00`);
    console.log(`Final Portfolio Value: $${balance.toFixed(2)}`);
    console.log(`Total Return: ${(((balance - 1000) / 1000) * 100).toFixed(2)}%`);
    console.log("---------------------------------");
    console.log(`Total Trades Taken: ${trades}`);
    if (trades > 0) {
        console.log(`Winning Trades: ${winningTrades}`);
        console.log(`Losing Trades: ${losingTrades}`);
        console.log(`Win Rate: ${((winningTrades / trades) * 100).toFixed(2)}%`);
    }
    console.log("=================================\n");
}

runBacktest().catch(console.error);
