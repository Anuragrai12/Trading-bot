const { getHistoricalData } = require('./dataFetcher');
const { analyzeDataAndGetSignal } = require('./strategy');

async function main() {
    console.log("🤖 Starting Rule-Based Paper Trading Bot...");
    console.log("[*] Using Free Binance API for BTCUSDT...");
    
    let simulatedBalance = 1000; // Starting with $1000 USDT
    let position = 0; // Amount of BTC held
    let entryPrice = 0; // The price at which we bought

    // Risk Management Parameters
    const STOP_LOSS_PERCENT = 0.02;   // 2% Stop Loss
    const TAKE_PROFIT_PERCENT = 0.05; // 5% Take Profit

    console.log("[*] Entering live trading loop. Press Ctrl+C to stop.");
    
    // Run loop every 10 seconds for testing (In real life, this would be 1 minute or more)
    setInterval(async () => {
        // 1. Fetch live/latest market data
        const data = await getHistoricalData('BTCUSDT', '1m', 50); // 1-minute candles
        
        if (!data) return;
        const currentPrice = data[data.length - 1].close;

        // --- Risk Management Check (Stop-Loss & Take-Profit) ---
        if (position > 0) {
            const lossPrice = entryPrice * (1 - STOP_LOSS_PERCENT);
            const profitPrice = entryPrice * (1 + TAKE_PROFIT_PERCENT);

            if (currentPrice <= lossPrice) {
                simulatedBalance = position * currentPrice;
                console.log(`🚨 [STOP LOSS HIT] Sold at $${currentPrice.toFixed(2)}. Balance is now $${simulatedBalance.toFixed(2)} USDT.`);
                position = 0;
                entryPrice = 0;
                return; // Skip strategy check this turn
            } 
            else if (currentPrice >= profitPrice) {
                simulatedBalance = position * currentPrice;
                console.log(`🎯 [TAKE PROFIT HIT] Sold at $${currentPrice.toFixed(2)}. Balance is now $${simulatedBalance.toFixed(2)} USDT.`);
                position = 0;
                entryPrice = 0;
                return; // Skip strategy check this turn
            }
        }

        // 2. Get Trading Signal from our Strategy
        const signal = analyzeDataAndGetSignal(data);
        
        // 3. Execute Paper Trade based on signal
        console.log(`💡 Signal: ${signal} | Current Price: $${currentPrice.toFixed(2)}`);
        
        if (signal === "BUY" && simulatedBalance > 0) {
            position = simulatedBalance / currentPrice;
            entryPrice = currentPrice;
            console.log(`🟢 [PAPER BUY] Executed at $${currentPrice.toFixed(2)}. Bought ${position.toFixed(5)} BTC.`);
            simulatedBalance = 0;
        } 
        else if (signal === "SELL" && position > 0) {
            simulatedBalance = position * currentPrice;
            console.log(`🔴 [PAPER SELL] Executed at $${currentPrice.toFixed(2)}. Balance is now $${simulatedBalance.toFixed(2)} USDT.`);
            position = 0;
            entryPrice = 0;
        }

        // Calculate total portfolio value
        const totalValue = simulatedBalance + (position * currentPrice);
        console.log(`💰 Portfolio Value: $${totalValue.toFixed(2)}\n-----------------------------------`);

    }, 10000); // 10 seconds
}

main().catch(console.error);
