const { RSI, SMA } = require('technicalindicators');

/**
 * A simple Rule-Based Strategy using RSI and Simple Moving Average (SMA).
 * No AI/ML is used here. We just follow mathematical rules.
 */
function analyzeDataAndGetSignal(data) {
    if (!data || data.length < 20) return "HOLD";

    // Extract closing prices from our data
    const closes = data.map(candle => candle.close);

    // 1. Calculate RSI (14 period)
    const rsiInput = { values: closes, period: 14 };
    const rsiResult = RSI.calculate(rsiInput);
    const currentRsi = rsiResult[rsiResult.length - 1];

    // 2. Calculate SMA (20 period)
    const smaInput = { values: closes, period: 20 };
    const smaResult = SMA.calculate(smaInput);
    const currentSma = smaResult[smaResult.length - 1];
    const currentPrice = closes[closes.length - 1];

    console.log(`📊 Analysis -> Price: $${currentPrice.toFixed(2)} | RSI: ${currentRsi?.toFixed(2)} | SMA(20): ${currentSma?.toFixed(2)}`);

    // --- Trading Logic / Rules ---
    
    // BUY Condition: If RSI is below 30 (Oversold - meaning a bounce is likely) 
    // OR if Price crosses above SMA (Uptrend starting)
    if (currentRsi < 30 || currentPrice > currentSma * 1.01) { // 1% above SMA to confirm trend
        return "BUY";
    }
    
    // SELL Condition: If RSI is above 70 (Overbought - meaning a drop is likely) 
    // OR Price drops below SMA (Downtrend starting)
    if (currentRsi > 70 || currentPrice < currentSma * 0.99) { // 1% below SMA to confirm drop
        return "SELL";
    }

    // Default action if no conditions are met
    return "HOLD";
}

module.exports = { analyzeDataAndGetSignal };
