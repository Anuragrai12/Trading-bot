const axios = require('axios');

async function getHistoricalData(symbol = 'BTCUSDT', interval = '1d', limit = 100) {
    try {
        console.log(`Fetching data for ${symbol}...`);
        // Using Binance public API for free, keyless historical data
        const response = await axios.get('https://api.binance.com/api/v3/klines', {
            params: {
                symbol: symbol,
                interval: interval,
                limit: limit
            }
        });
        
        // Map Binance response to standard OHLCV format
        const data = response.data.map(candle => ({
            time: new Date(candle[0]),
            open: parseFloat(candle[1]),
            high: parseFloat(candle[2]),
            low: parseFloat(candle[3]),
            close: parseFloat(candle[4]),
            volume: parseFloat(candle[5])
        }));
        
        console.log(`Successfully fetched ${data.length} candles.`);
        return data;
    } catch (error) {
        console.error("Error fetching data:", error.message);
        return null;
    }
}

module.exports = { getHistoricalData };

if (require.main === module) {
    getHistoricalData('BTCUSDT', '1d', 5).then(data => {
        if(data && data.length > 0) {
            console.log("Latest Candle:");
            console.table(data[data.length - 1]);
        }
    });
}

