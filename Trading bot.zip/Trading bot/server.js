require('dotenv').config();
const express = require('express');
const path = require('path');
const ccxt = require('ccxt');
const axios = require('axios');
const { getHistoricalData } = require('./dataFetcher');
const { analyzeDataAndGetSignal } = require('./strategy');

const app = express();
const PORT = 3000;

let lastAlertedSignal = null;

function sendTelegramAlert(message) {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;
    if (!token || !chatId) return;

    axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
        chat_id: chatId,
        text: message,
        disable_web_page_preview: true
    }, { timeout: 10000 }).catch((error) => {
        const status = error.response?.status;
        console.error('[Telegram] Alert delivery failed.', status ? `HTTP ${status}` : 'Check network and bot settings.');
    });
}

// Initialize Binance Testnet Client
const exchange = new ccxt.binance({
    apiKey: process.env.BINANCE_API_KEY,
    secret: process.env.BINANCE_API_SECRET,
    enableRateLimit: true,
});
exchange.setSandboxMode(true);

// Binance Spot Testnet is periodically reset, so load the current cycle's
// fills from the exchange instead of relying only on process memory.
const tradeHistory = [];
const TRADE_HISTORY_REFRESH_MS = 60 * 1000;
const TRADE_HISTORY_LIMIT = 1000;
let tradeHistoryFetchedAt = 0;
let tradeHistoryFetchPromise = null;
let tradeHistoryError = null;
let latestSignal = { signal: 'HOLD', price: 0, rsi: 0, sma: 0 };

// Serve static files from 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// API: Get wallet balance
app.get('/api/balance', async (req, res) => {
    try {
        const balance = await exchange.fetchBalance();
        const mainCoins = ['USDT', 'BTC', 'ETH', 'BNB', 'SOL', 'DOGE', 'XRP'];
        const filtered = {};
        for (const coin of mainCoins) {
            if (balance.total[coin] && balance.total[coin] > 0) {
                filtered[coin] = {
                    total: balance.total[coin],
                    free: balance.free[coin],
                    used: balance.used[coin] || 0
                };
            }
        }
        res.json({ success: true, balance: filtered });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

// API: Get live market data + signal
app.get('/api/market', async (req, res) => {
    try {
        const data = await getHistoricalData('BTCUSDT', '1m', 100);
        if (!data) return res.json({ success: false, error: 'No data' });

        const { RSI, SMA } = require('technicalindicators');
        const closes = data.map(c => c.close);
        
        const rsiResult = RSI.calculate({ values: closes, period: 14 });
        const smaResult = SMA.calculate({ values: closes, period: 20 });
        
        const currentRsi = rsiResult[rsiResult.length - 1];
        const currentSma = smaResult[smaResult.length - 1];
        const currentPrice = closes[closes.length - 1];

        // Get signal
        const signal = analyzeDataAndGetSignal(data);
        latestSignal = { signal, price: currentPrice, rsi: currentRsi, sma: currentSma };

        // Prepare chart data (last 50 candles)
        const chartData = data.slice(-50).map(c => ({
            time: c.time.toISOString(),
            open: c.open,
            high: c.high,
            low: c.low,
            close: c.close,
            volume: c.volume
        }));

        res.json({
            success: true,
            currentPrice,
            signal,
            rsi: currentRsi,
            sma: currentSma,
            chartData
        });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

async function refreshTradeHistoryIfNeeded() {
    if (tradeHistoryFetchPromise) return tradeHistoryFetchPromise;
    if (Date.now() - tradeHistoryFetchedAt < TRADE_HISTORY_REFRESH_MS) return;

    tradeHistoryFetchPromise = (async () => {
        try {
            if (!process.env.BINANCE_API_KEY || !process.env.BINANCE_API_SECRET) {
                throw new Error('Binance Testnet API credentials are missing. Set BINANCE_API_KEY and BINANCE_API_SECRET in .env.');
            }

            const fills = await exchange.fetchMyTrades('BTC/USDT', undefined, TRADE_HISTORY_LIMIT);
            const normalizedFills = fills.map((fill) => {
                const price = Number(fill.price) || 0;
                const amount = Number(fill.amount) || 0;
                return {
                    id: fill.id || `${fill.order || 'trade'}-${fill.timestamp}-${fill.side}`,
                    time: fill.datetime || new Date(fill.timestamp).toISOString(),
                    type: String(fill.side || 'unknown').toUpperCase(),
                    price,
                    amount,
                    value: Number(fill.cost) || price * amount
                };
            }).sort((a, b) => new Date(a.time) - new Date(b.time));

            tradeHistory.splice(0, tradeHistory.length, ...normalizedFills);
            tradeHistoryError = null;
            console.log(`[History] Loaded ${tradeHistory.length} BTC/USDT fills from Binance Testnet.`);
        } catch (error) {
            tradeHistoryError = error.message;
            console.error('[History] Could not load Binance Testnet trades:', error.message);
        } finally {
            tradeHistoryFetchedAt = Date.now();
            tradeHistoryFetchPromise = null;
        }
    })();

    return tradeHistoryFetchPromise;
}

// API: Get recent trade fills from the Binance Spot Testnet account.
app.get('/api/trades', async (req, res) => {
    await refreshTradeHistoryIfNeeded();
    res.json({
        success: tradeHistoryError === null,
        source: 'Binance Spot Testnet',
        trades: tradeHistory.slice(-TRADE_HISTORY_LIMIT),
        error: tradeHistoryError
    });
});

// API: Get bot status
app.get('/api/status', (req, res) => {
    res.json({
        success: true,
        botRunning: true,
        latestSignal,
        totalTrades: tradeHistory.length,
        uptime: process.uptime()
    });
});

// Start trading bot in the background
let inPosition = false;
const TRADE_AMOUNT_USDT = 100;

async function tradingLoop() {
    try {
        const data = await getHistoricalData('BTCUSDT', '1m', 50);
        if (!data) return;
        
        const currentPrice = data[data.length - 1].close;
        const signal = analyzeDataAndGetSignal(data);

        if (signal !== lastAlertedSignal) {
            lastAlertedSignal = signal;
            sendTelegramAlert(
                `BTC/USDT signal changed to ${signal}\nPrice: $${currentPrice.toFixed(2)}\nVenue: Binance Spot Testnet`
            );
        }

        if (signal === "BUY" && !inPosition) {
            const btcAmount = TRADE_AMOUNT_USDT / currentPrice;
            try {
                const roundedAmount = exchange.amountToPrecision('BTC/USDT', btcAmount);
                const order = await exchange.createMarketOrder('BTC/USDT', 'buy', roundedAmount);
                inPosition = true;
                tradeHistoryFetchedAt = 0; // Refresh history after a new order.
                sendTelegramAlert(
                    `BUY order successful\nBTC/USDT\nQuantity: ${roundedAmount} BTC\nPrice: $${currentPrice.toFixed(2)}\nOrder ID: ${order.id || 'not returned'}\nVenue: Binance Spot Testnet`
                );
                console.log(`🟢 [BUY] at $${currentPrice.toFixed(2)}`);
            } catch (e) {
                console.error("Order error:", e.message);
                sendTelegramAlert(`BUY order failed\nBTC/USDT\nError: ${e.message}\nVenue: Binance Spot Testnet`);
            }
        } 
        else if (signal === "SELL" && inPosition) {
            try {
                const bal = await exchange.fetchBalance();
                const btcToSell = bal.BTC?.free;
                if (btcToSell > 0) {
                    const roundedAmount = exchange.amountToPrecision('BTC/USDT', btcToSell);
                    const order = await exchange.createMarketOrder('BTC/USDT', 'sell', roundedAmount);
                    inPosition = false;
                    tradeHistoryFetchedAt = 0; // Refresh history after a new order.
                    sendTelegramAlert(
                        `SELL order successful\nBTC/USDT\nQuantity: ${roundedAmount} BTC\nPrice: $${currentPrice.toFixed(2)}\nOrder ID: ${order.id || 'not returned'}\nVenue: Binance Spot Testnet`
                    );
                    console.log(`🔴 [SELL] at $${currentPrice.toFixed(2)}`);
                }
            } catch (e) {
                console.error("Order error:", e.message);
                sendTelegramAlert(`SELL order failed\nBTC/USDT\nError: ${e.message}\nVenue: Binance Spot Testnet`);
            }
        }
    } catch (err) {
        console.error("Trading loop error:", err.message);
    }
}

// Run trading loop every 15 seconds
setInterval(tradingLoop, 15000);

// Start server
app.listen(PORT, () => {
    console.log(`\n🚀 Dashboard is LIVE at: http://localhost:${PORT}\n`);
    console.log(`🤖 Trading bot is running in the background...\n`);
});
